import React, { Component } from 'react'

export default class Test extends Component {
  render() {
    return (
      <div>
        My comp
      </div>
    )
  }
}
